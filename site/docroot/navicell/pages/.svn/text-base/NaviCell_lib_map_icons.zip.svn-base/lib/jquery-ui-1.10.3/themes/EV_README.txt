
2013-05-10
1. copied all directory themes from jquery-ui-themes-1.10.3
2. duplicated themes/base/jquery.ui.all.css to all these directories
